package com.hanyang.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class ThirdActivity extends AppCompatActivity {
    public void getMailId(View view){
        EditText textMailId=(EditText)findViewById(R.id.newmailid);
        String mailid=textMailId.getText().toString();

        Intent intent =new Intent(getApplicationContext(),MainActivity.class);
        intent.putExtra("mailid",mailid);
        setResult(RESULT_OK,intent);

        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
    }
}