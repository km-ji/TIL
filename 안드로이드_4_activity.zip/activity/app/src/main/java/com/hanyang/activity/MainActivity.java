package com.hanyang.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    String mailid="";
    public void gotoSecond(View view){
        Intent intent=new Intent(getApplicationContext(), SecondActivity.class);
        intent.putExtra("mailid", mailid);
        startActivity(intent);
    }
    public void gotoThird(View view){
        Intent intent=new Intent(getApplicationContext(), ThirdActivity.class);
        startActivityForResult(intent,0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent Data){
        super.onActivityResult(requestCode, resultCode, Data);
        if(requestCode==0){
            String id=Data.getStringExtra("mailid");
            if(id!=null){
                mailid=id;
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}