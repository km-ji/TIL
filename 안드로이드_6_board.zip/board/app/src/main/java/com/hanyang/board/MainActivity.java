package com.hanyang.board;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    public void gotoWriteForm(View view){
    Intent intent=new Intent(getApplicationContext(), writeform.class);
    startActivity(intent);
}

    public void gotoListForm(View view){
        Intent intent=new Intent(getApplicationContext(), listform.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}