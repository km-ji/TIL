package com.hanyang.board;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.lang.reflect.Member;
import java.util.HashMap;
import java.util.Map;

public class listform extends AppCompatActivity {
    public void processBack(View view){
        finish();
    }

    public void processGet(){
        ListView listView=(ListView) findViewById(R.id.listView);

        RequestQueue queue= Volley.newRequestQueue(this);
        String url="http://new.crossplatform.co.kr:23007/Process/hanyang/board.kis?owner=2005885";
        StringRequest stringRequest=new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>(){
                    @Override
                    public void onResponse(String response){
                        try{
                            ObjectMapper mapper=new ObjectMapper();
                            HashMap data=mapper.readValue(response, HashMap.class);
                            ListView simpleList;
                            String state=(String)data.get("state");
                            String message=(String)data.get("message");
                            if(state!=null&&state.equals("success")){
                                simpleList = (ListView) findViewById(R.id.listView);

                                String jsonResult=mapper.writeValueAsString(data.get("List"));
                                Board[] boardList=mapper.readValue(jsonResult, Board[].class);
                                CustomAdapter customAdapter=new CustomAdapter(
                                        getApplicationContext(), boardList);
                                simpleList.setAdapter(customAdapter);
                                //Toast.makeText(getApplicationContext(), response,Toast.LENGTH_LONG).show();
                            } else{
                                Toast.makeText(getApplicationContext(), "POST FAIL("+message+")", Toast.LENGTH_LONG).show();

                            }
                        }catch(Exception t){
                            Toast.makeText(getApplicationContext(), t.toString(), Toast.LENGTH_LONG).show();
                        }
                    }
                },  new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                NetworkResponse networkResponse = error.networkResponse;
                Toast.makeText(getApplicationContext(), "error" + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        queue.add(stringRequest);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listform);
        processGet();
    }
}