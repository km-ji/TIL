package com.hanyang.board;


import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.zip.Inflater;

public class CustomAdapter extends BaseAdapter {
    Context context;
    Board boardList[];
    LayoutInflater inflter;

    public CustomAdapter(Context applicationContext, Board[] boardList){
        this.context=context;
        this.boardList=boardList;
        inflter=(LayoutInflater.from(applicationContext));
    }

    @Override
    public int getCount() {
        return boardList.length;
    }

    @Override
    public Object getItem(int i) {
        return boardList[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup){
        view=inflter.inflate(R.layout.activity_listview, null);
        TextView textTitle=(TextView) view.findViewById(R.id.textView);
        textTitle.setText(boardList[i].getTitle());
        return view;
    }
}

