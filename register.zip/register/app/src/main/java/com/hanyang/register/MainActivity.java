package com.hanyang.register;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    public void processGet(View view){

    }

    public void processPut(View view){

    }

    public void processPost(View view){
        EditText uidText=(EditText) findViewById(R.id.id);
        String uid=uidText.getText().toString();
        EditText pwdText=(EditText) findViewById(R.id.pwd);
        String pwd=pwdText.getText().toString();
        EditText nickText=(EditText) findViewById(R.id.nick);
        String nick=nickText.getText().toString();
        TextView messageText=(TextView) findViewById(R.id.message);
        TextView stateText=(TextView) findViewById(R.id.state);

        RequestQueue queue= Volley.newRequestQueue(this);
        String url="http://new.crossplatform.co.kr:23007/Process/hanyang/member.kis";
        StringRequest stringRequest=new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>(){
                    @Override
                    public void onResponse(String response){
                        try{
                            ObjectMapper mapper=new ObjectMapper();
                            HashMap data=mapper.readValue(response, HashMap.class);
                            String jsonResult=mapper.writeValueAsString(data.get("member"));
                            Member member=mapper.readValue(jsonResult, Member.class);
                            String state=(String)data.get("state");
                            String message=(String)data.get("message");
                            messageText.setText(message);
                            stateText.setText(state);
                        }catch(Exception t){
                            Toast.makeText(getApplicationContext(), t.toString(), Toast.LENGTH_LONG).show();
                        }
                   }
                },  new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                NetworkResponse networkResponse = error.networkResponse;
                Toast.makeText(getApplicationContext(), "error" + error.getMessage(), Toast.LENGTH_SHORT).show();
                Log.d("STATE", error.getMessage());
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params=new HashMap();
                params.put("id",uid);
                params.put("pwd",pwd);
                params.put("nick",nick);
                return params;
            }
        };
        queue.add(stringRequest);
    }

    public void processDelete(View view){

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

}