package com.hanyang.register;

public @interface JsonAnySetter {
}
