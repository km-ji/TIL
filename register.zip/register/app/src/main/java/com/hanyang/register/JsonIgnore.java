package com.hanyang.register;

public @interface JsonIgnore {
}
