package com.hanyang.register;

public @interface JsonProperty {
}
