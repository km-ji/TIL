package com.hanyang.register;

public @interface JsonPropertyOrder {
}
