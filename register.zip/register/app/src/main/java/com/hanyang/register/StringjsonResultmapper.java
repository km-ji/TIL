package com.hanyang.register;

public class StringjsonResultmapper {
    public static void writeValueAsString(Object member) {
    }
}
