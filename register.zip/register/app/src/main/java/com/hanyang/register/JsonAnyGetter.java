package com.hanyang.register;

public @interface JsonAnyGetter {
}
