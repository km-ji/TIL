package com.hanyang.register;

public @interface JsonInclude {
    public class Include {
        public static final Object NON_NULL =  ;
    }
}
