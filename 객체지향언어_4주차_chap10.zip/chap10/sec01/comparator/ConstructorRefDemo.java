package chap10.sec01.comparator;

//함수형 인터페이스
interface NewObject<T>{T getObject(T o);}
interface NewArray<T>{T[] getArray(int size);}

public class ConstructorRefDemo {
	public static void main(String[] args) {
		//NewObject<String> s=x -> new String(x);
		NewObject<String> s=String::new;//생성자 참조
		String str=s.getObject("사과");
		System.out.println(str);
		
		//NewArray<Integer> i=x -> new Integer[x];
		NewArray<Integer> i=Integer[]::new; //배열 생성자 참조
		Integer[] array=i.getArray(2);
		array[0]=100;
		array[1]=200;
		for (int k=0;k<array.length;k++) {
			System.out.print(array[k]+"\t");
		}
	}
}
