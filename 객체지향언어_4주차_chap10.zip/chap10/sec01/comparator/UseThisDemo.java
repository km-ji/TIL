package chap10.sec01.comparator;

interface UseThis{void use();}

public class UseThisDemo {
	public void lambda() {
		String hi="Hi!";
		
		UseThis u1=new UseThis() {//익명 지역 객체
			public void use() {
				System.out.println(this);//지역객체의 this는 UseThis
				hi=hi+"Lambda.";//지역 객체에서 사용되는 외부 지역변수는 final이므로 변경 불가
			}
		};
		u1.use();
		
		UseThis u2=()->{//람다식
			System.out.println(this);//람다식의 this는 람다식으로 사용하는 UseThisDemo
			hi=hi+"Lambda.";
		};
		u2.use();
	}
	
	public String toString() {
		return "UseThisDemo";
	}
	
	public static void main(String[] args) {
		int one=1;
		new UseThisDemo().lambda();
		//람다식의 선언부에 외부에서 선언된 동일한 이름의 변수를 사용할 수 없음
		Comparator<String> c=(one, two) -> one.length() - two.length();
	}

}
