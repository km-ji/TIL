package chap10.sec01.comparator;

public interface CarConsumer {
	void accept(Car car);
}
