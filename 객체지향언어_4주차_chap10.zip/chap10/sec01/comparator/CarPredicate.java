package chap10.sec01.comparator;

public interface CarPredicate {
	boolean test(Car car);
}
