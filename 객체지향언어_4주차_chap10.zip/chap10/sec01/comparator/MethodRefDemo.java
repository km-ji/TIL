package chap10.sec01.comparator;

//함수형 인터페이스
interface Mathematical{double calculate(double d);}
interface Pickable{char pick(String s, int i);}
interface Computable{int compute(int x, int y);}
//인스턴스 메서드 포함 클래스

class Utils{
	int add(int a, int b) {return a+b;}
}

public class MethodRefDemo {
	public static void main(String[] args) {
		//Mathematical m=d -> Math.abs(d);
		Mathematical m=Math::abs;//정메서드 참조
		System.out.println(m.calculate(-50.3));
		
		//Pickable p=(a,b) -> a.charAt(b);//인스턴스 메서드 참조
		Pickable p=String::charAt;
		System.out.println(p.pick("안녕, 인스턴스 메서드 참조!", 4));
		
		Utils utils=new Utils();
		//Computable c=(a,b) -> utils.add(a,b);
		Computable c=utils::add; //인스턴스 메서드 참조
		System.out.println(c.compute(20, 30));
	}
}
