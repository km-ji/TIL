package chap10.sec01.comparator;

import java.util.ArrayList;
import java.util.List;

public class CarDemo {
	public static void main(String[] args) {
		List<Car> dieselCars=findCars(Car.cars, c-> !c.isGasoline());//가솔린 자동차 아니면 true 반환 람다식
		System.out.println("디젤 자동차 = "+ dieselCars);
		
		List<Car> oldCars=findCars(Car.cars, c->c.getAge() > 10);//10년보다 오래된 자동차이면 true 반환 람다식
		System.out.println("오래된 자동차 : "+oldCars);
		
		List<Car> oldDieselCars=findCars(Car.cars, c->c.getAge() > 10 && !c.isGasoline());//오래된 디젤자동차이면 true 반환 람다식
		System.out.println("오래된 디젤 자동차 = "+oldDieselCars);
		
		System.out.print("디젤 자동차 = ");
		printCars(dieselCars, c->System.out.printf("%s(%d)", c.getModel(), c.getAge()));//자동차를 모델과 연식만 출력하도록 하는 람다식
		System.out.print("\n오래된 자동차 = ");
		printCars(oldCars, c->System.out.printf("%s(%d, %d)", c.getModel(), c.getAge(), c.getMileage()));
	}
	
	public static List<Car> findCars(List<Car> all, CarPredicate cp){
		List<Car> result=new ArrayList<>();
		
		for  (Car car:all) {
			if (cp.test(car))//test() 메서더는 9라인, 12라인, 15라인 람다식 실행
				result.add(car);
		}
		return result;
	}
	
	public static void printCars(List<Car> all, CarConsumer cc) {
		for (Car car:all) {
			cc.accept(car); //apply()메서드는 19라인, 21라인 람다식 실행
		}
	}
}//CarDemo클래스  끝
