package chap10.sec01.comparator;

//추상메서드가 1개인 함수형 인터페이스
interface Negative{int neg(int x);}
interface Printable{void print();}

public class Lambda02Demo {
	public static void main(String[] args) {
		//모두 같은 의미의 람다식 표현
		Negative n=(int x)->{return -x;};
		//n=(x)->{return -x;};
		//n=x -> {return -x;};
		//n=(int x) -> -x;
		//n=(x) -> -x;
		//n=x -> -x;
		//매개변수가 없으므로 선언부에 괄호에 사용해야 함
		
		Printable p =() -> {System.out.println("안녕!");};
		p.print();
		p=()->System.out.println("안녕!");
		p.print();
		p=()->System.out.println(n.neg(124));
		p.print();
	}

}
