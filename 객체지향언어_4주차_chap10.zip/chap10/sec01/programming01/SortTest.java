package chap10.sec01.programming01;

import java.util.Arrays;
import java.util.Comparator;

public class SortTest {
	public static void main(String[] args) {
		String[] sa= {"K","o","r","e","a","n"};
		System.out.print("정렬 전 : ");
		for (String s:sa) System.out.print(s+" ");
		System.out.println();
		//익명 객체 생성 표기법
		Arrays.sort(sa, new Comparator<String>(){
			public int compare(String s1, String s2) {
				return s1.compareToIgnoreCase(s2);
			}
		});
		System.out.print("정렬 후(익명객체 생성 표기) : ");
		for (String s:sa) System.out.print(s+" ");
		System.out.println();
		//람다식 표기
		
		Arrays.sort(sa,(s1,s2)->s1.compareToIgnoreCase(s2));
		System.out.print("정렬 후(람다식 표기) : ");
		for (String s:sa) System.out.print(s+ " ");
		System.out.println();
		//메서드 참조 표기
		Arrays.sort(sa, String::compareToIgnoreCase);
		System.out.print("정렬 후(메서드 참조 표기) : ");
		for (String s: sa)
			System.out.print(s+" ");
	}
}
