package chap10.sec01.programming02;

//함수형 인터페이스
interface Wordable{
	void word();//매개변수도 없고, 리턴값도 없음
}

public class WordableTest {
	public static void main(String[] args) {
		//인터페이스 타입 배열
		Wordable[] m={
			()->System.out.println("가위"),
			()->System.out.println("나비"),
			()->System.out.println("다리"),
			()->System.out.println("마차")
		};
		for (Wordable e:m)
			e.word();
	}
}
