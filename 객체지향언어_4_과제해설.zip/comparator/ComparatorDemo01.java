package chap10.sec01.comparator;

import java.util.Comparator;
import java.util.Arrays;

class Rectangle implements Comparable<Rectangle> {
	private int width, height;
	private String color;
	
	public Rectangle(int width, int height, String color) {
		this.width=width;
		this.height=height;
		this.color=color;
	}
	public String getColor() {
		return this.color;
	}
	public int findArea() {
		return width*height;
	}
	public String toString() {
		return String.format("사각형[색깔=%s, 폭=%d, 높이=%d]", color, width, height);
	}
	public int compareTo(Rectangle o) {
		return findArea()-o.findArea();
	}

}

public class ComparatorDemo01 {
	public static void main(String[] args) {
		Rectangle[] rectangles= {
				new Rectangle(3,5,"빨강"),
				new Rectangle(2,10,"노랑"),
				new Rectangle(5,5,"파랑")
		};
		
		//Comparator 함수형 인터페이스를 익명 객체로 작성
		Arrays.sort(rectangles, new Comparator<Rectangle>() {
			public int compare(Rectangle r1, Rectangle r2) {
				return r1.getColor().compareTo(r2.getColor());
			}
		});
		
		for (Rectangle r: rectangles)
			System.out.println(r);
	}
}
