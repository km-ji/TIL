package chap10.sec01.comparator;
import java.util.Comparator;
import java.util.Arrays;

public class ComparatorDemo01_lamda {
	public static void main(String[] args) {
		Rectangle[] rectangles= {
				new Rectangle(3,5,"빨강"),
				new Rectangle(2,10,"노랑"),
				new Rectangle(5,5,"파랑")
		};
		//Comparator 함수형 인터페이스를 익명 객체로 작성
		Arrays.sort(rectangles, new Comparator<Rectangle>() {
			public int compare(Rectangle r1, Rectangle r2) {
				return r1.getColor().compareTo(r2.getColor());
			}
		});
		
		//Comparator 함수형 인터페이스를 람다식으로 작성
		Arrays.sort(rectangles, (r1,r2)-> r1.getColor().compareTo(r2.getColor()));
		
		for (Rectangle r:rectangles)
			System.out.println(r);
	}
}