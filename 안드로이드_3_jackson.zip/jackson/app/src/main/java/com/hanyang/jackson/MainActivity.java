package com.hanyang.jackson;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getData("http://new.crossplatform.co.kr:23007/Process/hanyang/member.kis?id-ooranos");    }

    private void getData(String s) {
    }
}