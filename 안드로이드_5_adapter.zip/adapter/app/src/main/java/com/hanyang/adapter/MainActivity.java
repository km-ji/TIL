package com.hanyang.adapter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.GridView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    GridView simpleList;
    String countryList[] = {"India", "China", "australia", "Portugle", "America", "NewZealand"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        simpleList = (GridView)findViewById(R.id.simpleListView);
        CustomAdapter customAdapter=new CustomAdapter(
                getApplicationContext(), countryList);
        simpleList.setAdapter(customAdapter);
    }
}